/**
 * Poolbuyr cart bridge for WooCommerce — the Tier-2 half of the handoff.
 *
 * The loader (`https://cdn.poolbuyr.com:444/v1/widget.js`, enqueued by
 * poolbuyr.php) draws the widget. This file does the two things a pasted
 * snippet cannot:
 *
 *   1. hands the WooCommerce cart to the widget, with this shop's own product
 *      and variation ids, so a pooled order can be rebuilt as a real cart;
 *   2. defines `window.PoolbuyrWidget.buildCart`, which rebuilds the pooled
 *      basket in this shop's own cart and sends the buyer to this shop's
 *      checkout instead of over to poolbuyr.com.
 *
 * Everything here runs on someone else's storefront: no error may escape into
 * the shop's page, and a failure must leave the shopper somewhere they can
 * finish the job rather than with a cart that quietly did nothing.
 */
( function () {
	'use strict';

	var config = window.poolbuyrConfig;

	if ( ! config || ! config.handoffUrl || ! config.cartUrl ) {
		return;
	}

	var CART_MAX_LINES = 50; // the widget carries 1–50 lines; more is not its contract

	/**
	 * Navigates the top window, and does not assume it is allowed to.
	 *
	 * This is also where both failure paths below end up: the pool page is the
	 * one place the shopper can always finish, so a broken handoff must never
	 * leave them staring at an unchanged cart with no explanation.
	 *
	 * @param {string} url Destination.
	 */
	function go( url ) {
		if ( ! url ) {
			return;
		}
		try {
			window.top.location.href = url;
		} catch ( e ) {
			// The shop page is framed cross-origin, so `top` is not ours to write.
			window.location.href = url;
		}
	}

	/* --- this shop's cart -> the widget ------------------------------------- */

	/**
	 * Reads the cart from the plugin's own endpoint and hands it to the widget.
	 *
	 * Server-side on purpose: the cart lives in the WooCommerce session, and the
	 * `product_id`/`variation_id` pair only exists there. Rendering it into the
	 * page instead would put one shopper's basket into the HTML of a page the
	 * shop's page cache is about to serve to the next visitor.
	 */
	function pushCart( widget ) {
		window.fetch( config.cartUrl, { credentials: 'same-origin' } )
			.then( function ( response ) {
				return response.ok ? response.json() : null;
			} )
			.then( function ( data ) {
				// An empty cart is not worth a round trip into the iframe; the
				// embed keeps whatever it last heard.
				if ( data && data.items && data.items.length ) {
					widget.setCart( data.items.slice( 0, CART_MAX_LINES ) );
				}
			} )
			.catch( function () {
				// No readable cart: the widget simply gets none.
			} );
	}

	/* --- the widget's handoff -> this shop's cart --------------------------- */

	/**
	 * Turns one widget line into one cart line, or null when it cannot be
	 * ordered. One line without a usable id poisons the whole basket — a partial
	 * cart is only noticed at checkout (doc/vendor/integration-guide.md §3).
	 *
	 * @param {Object} item Widget line.
	 * @return {?Object} Line for the handoff endpoint.
	 */
	function toLine( item ) {
		var productId = Math.floor( Number( item && item.productId ) );
		var quantity = Math.floor( Number( item && item.quantity ) );

		if ( ! isFinite( productId ) || productId < 1 || ! isFinite( quantity ) || quantity < 1 ) {
			return null;
		}

		var variantId = Math.floor( Number( item && item.variantId ) );

		return {
			productId: productId,
			variantId: isFinite( variantId ) && variantId > 0 ? variantId : 0,
			quantity: quantity
		};
	}

	/**
	 * The Tier-2 hook. The loader calls this the instant a shopper joins a pool
	 * and does NOT await it — it marks the handoff as taken as soon as this
	 * returns and cancels its own navigation. So an async rejection here is
	 * invisible: the buyer would stay on the shop with an unchanged cart and the
	 * loader's fallback (navigate the top window to `ctx.url`) would never fire,
	 * because the loader believes the shop took the click. This function owns
	 * its failure path and navigates to `ctx.url` itself. It looks redundant
	 * next to the loader's fallback; it is the only fallback that actually runs.
	 *
	 * @param {Array}  items Widget lines.
	 * @param {Object} ctx   `{ url, poolId }`.
	 */
	function buildCart( items, ctx ) {
		var poolUrl = ( ctx && ctx.url ) || '';
		var lines = ( items || [] ).slice( 0, CART_MAX_LINES ).map( toLine );

		if ( ! lines.length || lines.some( function ( line ) {
			return ! line;
		} ) ) {
			go( poolUrl );
			return;
		}

		// One request for the whole basket: the shop's cart endpoint adds the
		// lines all-or-nothing, so a half-added pool can never reach checkout.
		window.fetch( config.handoffUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify( { items: lines } )
		} ).then( function ( response ) {
			return response.json().catch( function () {
				// A non-JSON body means something other than WordPress answered
				// (a security plugin, a redirect); treat it as a failed handoff.
				return null;
			} ).then( function ( body ) {
				if ( ! response.ok ) {
					throw new Error( 'handoff: HTTP ' + response.status );
				}
				// Refused adds come back as HTTP 200 `{"success":false}`.
				if ( ! body || ! body.success ) {
					throw new Error( 'handoff: refused' );
				}
				return body;
			} );
		} ).then( function () {
			go( config.checkoutUrl || poolUrl );
		} ).catch( function () {
			go( poolUrl );
		} );
	}

	/* --- wire it up --------------------------------------------------------- */

	// The loader assigns a brand-new `window.PoolbuyrWidget` object when it
	// executes, so a hook defined before it arrives would be overwritten by
	// `buildCart: null`. It loads with `async` and announces itself with no
	// event, so poll for it instead of assigning into a void. The cap stops the
	// timer on a page where the loader never showed up (CDN blocked, key removed
	// mid-edit).
	var waited = 0;

	( function whenReady() {
		var widget = window.PoolbuyrWidget;

		if ( widget && widget.__v1 ) {
			widget.buildCart = buildCart;
			pushCart( widget );

			// WooCommerce refreshes cart fragments after every AJAX cart change;
			// re-reading then keeps the widget from quoting a cart the shopper has
			// since edited without a page load. Themes that do not run the
			// fragments script leave the widget with the cart from page load,
			// which is still a usable basket — just not a fresh one.
			var refresh = function () {
				pushCart( widget );
			};

			if ( window.jQuery && document.body ) {
				window.jQuery( document.body ).on( 'wc_fragments_refreshed wc_fragments_loaded', refresh );
			}

			// Back/forward out of the bfcache restores a page whose cart may have
			// moved on.
			window.addEventListener( 'pageshow', refresh );
			return;
		}

		waited += 100;
		if ( waited <= 10000 ) {
			window.setTimeout( whenReady, 100 );
		}
	} )();
} )();
