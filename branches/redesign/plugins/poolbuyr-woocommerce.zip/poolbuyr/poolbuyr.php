<?php
/**
 * Plugin Name:       Poolbuyr
 * Plugin URI:        https://poolbuyr.com
 * Description:       Shows the Poolbuyr pooling widget on your storefront and turns a pool a shopper joins into a real WooCommerce cart at this shop's checkout.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Poolbuyr
 * Author URI:        https://poolbuyr.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       poolbuyr
 *
 * @package Poolbuyr
 */

defined( 'ABSPATH' ) || exit;

define( 'POOLBUYR_VERSION', '1.0.0' );

/**
 * The loader is served from the CDN, never from this plugin: the `/v1/` path
 * segment is the cache key, so a published loader is never edited in place and
 * the plugin never has to re-ship it.
 */
define( 'POOLBUYR_LOADER_URL', 'https://cdn.poolbuyr.com:444/v1/widget.js' );

/** The widget carries 1–50 lines; anything beyond that is not its contract. */
define( 'POOLBUYR_MAX_LINES', 50 );

/**
 * Reads the configured publishable key.
 *
 * Public by design — it ships in the storefront HTML and identifies the vendor
 * account to Poolbuyr. Nothing secret ever belongs in this option or in the
 * front-end output that follows from it.
 *
 * @return string
 */
function poolbuyr_publishable_key() {
	return trim( (string) get_option( 'poolbuyr_key', '' ) );
}

/**
 * Reads the configured app origin.
 *
 * @return string
 */
function poolbuyr_app_origin() {
	return trim( (string) get_option( 'poolbuyr_app', '' ) );
}

/* -------------------------------------------------------------------------
 * Settings
 * ---------------------------------------------------------------------- */

/**
 * Registers the two options.
 *
 * Sanitising happens here rather than on output: the key reaches a `data-`
 * attribute and the origin reaches an iframe `src`, and everything downstream
 * of this can then treat both as trusted.
 */
function poolbuyr_register_settings() {
	register_setting(
		'poolbuyr',
		'poolbuyr_key',
		array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'poolbuyr_sanitize_key',
		)
	);

	register_setting(
		'poolbuyr',
		'poolbuyr_app',
		array(
			'type'              => 'string',
			'default'           => '',
			'sanitize_callback' => 'poolbuyr_sanitize_app',
		)
	);

	add_settings_section( 'poolbuyr_main', __( 'Storefront widget', 'poolbuyr' ), 'poolbuyr_settings_intro', 'poolbuyr' );

	add_settings_field(
		'poolbuyr_key',
		__( 'Publishable key', 'poolbuyr' ),
		'poolbuyr_field_key',
		'poolbuyr',
		'poolbuyr_main',
		array( 'label_for' => 'poolbuyr_key' )
	);

	add_settings_field(
		'poolbuyr_app',
		__( 'App origin', 'poolbuyr' ),
		'poolbuyr_field_app',
		'poolbuyr',
		'poolbuyr_main',
		array( 'label_for' => 'poolbuyr_app' )
	);
}
add_action( 'admin_init', 'poolbuyr_register_settings' );

/**
 * Rejects a key that cannot be one, rather than saving it and leaving the
 * merchant with a widget that silently never mounts.
 *
 * @param string $value Raw submitted value.
 * @return string
 */
function poolbuyr_sanitize_key( $value ) {
	$value = trim( sanitize_text_field( (string) $value ) );

	if ( '' !== $value && ! preg_match( '/^pk_[a-z]+_[A-Za-z0-9_-]+$/', $value ) ) {
		add_settings_error(
			'poolbuyr_key',
			'poolbuyr_key_format',
			__( 'That is not a Poolbuyr publishable key (they look like pk_live_… or pk_test_…). Nothing was saved, and the widget stays off until a key is.', 'poolbuyr' )
		);

		return '';
	}

	return $value;
}

/**
 * Keeps the saved origin a URL, and an https one.
 *
 * @param string $value Raw submitted value.
 * @return string
 */
function poolbuyr_sanitize_app( $value ) {
	$value = trim( (string) $value );

	if ( '' === $value ) {
		return '';
	}

	// esc_url() adds http:// to a scheme-less host, which would put an http
	// iframe on an https shop and get it blocked as mixed content. The app is
	// always https, so assume it rather than saving something unusable.
	if ( ! preg_match( '#^[a-z][a-z0-9+.-]*://#i', $value ) ) {
		$value = 'https://' . $value;
	}

	$url = esc_url_raw( $value, array( 'https', 'http' ) );

	if ( '' === $url ) {
		add_settings_error(
			'poolbuyr_app',
			'poolbuyr_app_invalid',
			__( 'That is not a URL. Leave the field empty to use the default origin.', 'poolbuyr' )
		);

		return '';
	}

	// The loader strips a trailing slash itself; storing the canonical form keeps
	// a later comparison against the embed's postMessage origin predictable.
	return untrailingslashit( $url );
}

function poolbuyr_settings_intro() {
	echo '<p>' . esc_html__( 'The widget lets neighbours pool one order so shipping is shared. Paste the publishable key from your Poolbuyr vendor portal — the plugin loads the widget on every storefront page and gives it your WooCommerce cart.', 'poolbuyr' ) . '</p>';
	echo '<p>' . esc_html__( 'It mounts at the end of the page, because an enqueued script tag has no theme-defined place to sit. To put the widget inside your own layout, paste the snippet from the portal into a template instead of using this plugin.', 'poolbuyr' ) . '</p>';
}

function poolbuyr_field_key() {
	printf(
		'<input type="text" id="poolbuyr_key" name="poolbuyr_key" value="%s" class="regular-text code" autocomplete="off" spellcheck="false" />',
		esc_attr( poolbuyr_publishable_key() )
	);
	echo '<p class="description">' . esc_html__( 'Public: it appears in your storefront HTML. Until it is set, nothing is loaded and no widget is shown.', 'poolbuyr' ) . '</p>';
}

function poolbuyr_field_app() {
	printf(
		'<input type="text" id="poolbuyr_app" name="poolbuyr_app" value="%s" class="regular-text code" placeholder="%s" autocomplete="off" spellcheck="false" />',
		esc_attr( poolbuyr_app_origin() ),
		esc_attr( 'https://poolbuyr.com' )
	);
	echo '<p class="description">' . esc_html__( 'Only change this for a staging or branch origin. Leave empty for https://poolbuyr.com.', 'poolbuyr' ) . '</p>';
}

function poolbuyr_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
		<form action="options.php" method="post">
			<?php
			settings_fields( 'poolbuyr' );
			do_settings_sections( 'poolbuyr' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

function poolbuyr_add_settings_page() {
	add_options_page(
		__( 'Poolbuyr', 'poolbuyr' ),
		__( 'Poolbuyr', 'poolbuyr' ),
		'manage_options',
		'poolbuyr',
		'poolbuyr_settings_page'
	);
}
add_action( 'admin_menu', 'poolbuyr_add_settings_page' );

/* -------------------------------------------------------------------------
 * WooCommerce
 * ---------------------------------------------------------------------- */

if ( ! class_exists( 'WooCommerce' ) ) {
	/**
	 * Everything below needs the cart, so without WooCommerce the plugin has
	 * nothing to do — but it must not fatal while the merchant is installing it.
	 */
	function poolbuyr_woocommerce_missing_notice() {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-warning"><p>' . esc_html__( 'Poolbuyr needs WooCommerce: it reads your cart and rebuilds a pooled order in it. Install and activate WooCommerce to use the widget.', 'poolbuyr' ) . '</p></div>';
	}
	add_action( 'admin_notices', 'poolbuyr_woocommerce_missing_notice' );

	return;
}

/**
 * The plugin only reads the cart and adds to it; it never touches orders, so
 * WooCommerce's order tables are irrelevant to it. Declaring that keeps the
 * merchant from seeing a false incompatibility warning on WC 7.1+.
 */
function poolbuyr_declare_woocommerce_compatibility() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	}
}
add_action( 'before_woocommerce_init', 'poolbuyr_declare_woocommerce_compatibility' );

/**
 * Loads the loader and the storefront hook.
 */
function poolbuyr_enqueue_storefront() {
	if ( is_admin() ) {
		return;
	}

	if ( '' === poolbuyr_publishable_key() ) {
		// An unkeyed loader returns immediately, so the request would buy nothing.
		return;
	}

	// null version: /v1/ in the path is the cache key, and a ?ver= query on a CDN
	// asset only invites a redundant copy per WordPress release.
	wp_enqueue_script( 'poolbuyr-widget', POOLBUYR_LOADER_URL, array(), null, true );
	wp_enqueue_script( 'poolbuyr-frontend', plugins_url( 'assets/js/poolbuyr.js', __FILE__ ), array(), POOLBUYR_VERSION, true );

	$config = array(
		'cartUrl'      => add_query_arg( 'action', 'poolbuyr_cart', admin_url( 'admin-ajax.php' ) ),
		'handoffUrl'   => add_query_arg( 'action', 'poolbuyr_handoff', admin_url( 'admin-ajax.php' ) ),
		'checkoutUrl'  => wc_get_checkout_url(),
	);

	// wp_add_inline_script rather than a printed <script> tag: WordPress owns the
	// tag, its position and its escaping, and wp_json_encode escapes the values
	// for a script context.
	wp_add_inline_script( 'poolbuyr-frontend', 'window.poolbuyrConfig = ' . wp_json_encode( $config ) . ';', 'before' );
}
add_action( 'wp_enqueue_scripts', 'poolbuyr_enqueue_storefront' );

/**
 * Gives the loader tag its `data-*` attributes.
 *
 * WordPress has no API for arbitrary attributes on an enqueued script (WP 6.3's
 * `strategy` covers async/defer only), so they are added once core has built the
 * tag. `str_replace` on ` src=` — the part before the quote — works whichever
 * quote style core uses.
 *
 * @param string $tag    The script tag core is about to print.
 * @param string $handle Script handle.
 * @return string
 */
function poolbuyr_script_attributes( $tag, $handle ) {
	if ( 'poolbuyr-widget' !== $handle ) {
		return $tag;
	}

	$attributes = 'async data-key="' . esc_attr( poolbuyr_publishable_key() ) . '"';

	// Without this the loader mounts the widget next to the script tag, which for
	// an enqueued script is wherever the theme happens to print the footer. The
	// end of <body> is not ideal placement, but it is predictable and does not
	// move with the theme; a shop that wants the widget inside its own layout
	// should use the snippet from the vendor portal instead.
	$attributes .= ' data-position="bottom"';

	$app = poolbuyr_app_origin();
	if ( '' !== $app ) {
		// Omitting the attribute lets the loader fall back to its own default.
		$attributes .= ' data-app="' . esc_attr( $app ) . '"';
	}

	return str_replace( ' src=', ' ' . $attributes . ' src=', $tag );
}
add_filter( 'script_loader_tag', 'poolbuyr_script_attributes', 10, 2 );

/**
 * Loads the session-backed cart for an AJAX request.
 *
 * WooCommerce has not necessarily booted the session by the time an admin-ajax
 * handler runs, and WC()->cart is null until it has — reaching into it without
 * this is the classic "call to a member function on null" fatality.
 *
 * @return WC_Cart|null
 */
function poolbuyr_cart() {
	if ( function_exists( 'wc_load_cart' ) ) {
		wc_load_cart();
	}

	return isset( WC()->cart ) ? WC()->cart : null;
}

/**
 * Returns the shopper's cart in the shape `setCart` expects.
 *
 * Read over admin-ajax rather than REST because it needs the WooCommerce session
 * — the cart lives in the session, not in a table. Ids come from the cart item
 * itself: `product_id` is the parent and `variation_id` the variant, which is
 * exactly what adding the line back later needs.
 */
function poolbuyr_ajax_cart() {
	// The response is one shopper's cart. Nothing between here and the browser
	// may cache it and hand it to the next visitor.
	nocache_headers();

	$cart = poolbuyr_cart();

	if ( ! $cart ) {
		wp_send_json( array( 'items' => array() ) );
	}

	$items = array();

	// The embed accepts at most 50 lines; sending more would be truncated anyway.
	foreach ( array_slice( $cart->get_cart(), 0, POOLBUYR_MAX_LINES ) as $line ) {
		$product  = isset( $line['data'] ) && is_object( $line['data'] ) ? $line['data'] : null;
		$quantity = isset( $line['quantity'] ) ? (int) $line['quantity'] : 0;

		if ( ! $product || $quantity < 1 ) {
			continue;
		}

		$item = array(
			'title'     => $product->get_name(),
			'productId' => (int) $line['product_id'],
			'quantity'  => $quantity,
			// What this line costs per unit in this cart rather than the current
			// catalog price: a sale can end between adding and pooling, and the
			// shopper is looking at the number they were charged.
			'unitPrice' => round( (float) $line['line_subtotal'] / $quantity, wc_get_price_decimals() ),
		);

		if ( ! empty( $line['variation_id'] ) ) {
			$item['variantId'] = (int) $line['variation_id'];
		}

		$items[] = $item;
	}

	wp_send_json( array( 'items' => $items ) );
}
add_action( 'wp_ajax_poolbuyr_cart', 'poolbuyr_ajax_cart' );
add_action( 'wp_ajax_nopriv_poolbuyr_cart', 'poolbuyr_ajax_cart' );

/**
 * Reads the pooled lines out of the request body.
 *
 * Bounded and validated before any of it reaches the cart: the ids are the
 * shop's own (they came from this shop's cart in the first place, through
 * `setCart`), and a line is either fully usable or the whole handoff fails —
 * see `poolbuyr_ajax_handoff()`.
 *
 * @return array|WP_Error
 */
function poolbuyr_request_lines() {
	$raw  = file_get_contents( 'php://input' );
	$body = is_string( $raw ) ? json_decode( $raw, true ) : null;

	if ( ! is_array( $body ) || empty( $body['items'] ) || ! is_array( $body['items'] ) ) {
		return new WP_Error( 'poolbuyr_empty', __( 'No items were handed over.', 'poolbuyr' ) );
	}

	if ( count( $body['items'] ) > POOLBUYR_MAX_LINES ) {
		return new WP_Error( 'poolbuyr_too_many', __( 'More lines than the widget can hand over.', 'poolbuyr' ) );
	}

	$lines = array();

	foreach ( $body['items'] as $item ) {
		$product_id = is_array( $item ) && isset( $item['productId'] ) ? absint( $item['productId'] ) : 0;
		$quantity   = is_array( $item ) && isset( $item['quantity'] ) ? (int) $item['quantity'] : 0;

		if ( $product_id < 1 || $quantity < 1 ) {
			return new WP_Error( 'poolbuyr_bad_line', __( 'A pooled line has no usable product or quantity.', 'poolbuyr' ) );
		}

		$lines[] = array(
			'product_id'   => $product_id,
			'variation_id' => isset( $item['variantId'] ) ? absint( $item['variantId'] ) : 0,
			'quantity'     => $quantity,
		);
	}

	return $lines;
}

/**
 * Puts a partly-added basket back the way it was.
 *
 * A line that was already in the cart is merged into rather than appended —
 * `WC_Cart::add_to_cart()` returns the existing item's key and adds to its
 * quantity — so the earlier quantity has to be restored, not the line removed,
 * or the undo would take the shopper's own line with it.
 *
 * @param WC_Cart $cart   The cart being written to.
 * @param array   $before Cart contents before the first add.
 * @param array   $added  Keys the adds returned.
 */
function poolbuyr_undo_lines( $cart, $before, $added ) {
	foreach ( array_unique( $added ) as $key ) {
		if ( isset( $before[ $key ] ) ) {
			$cart->set_quantity( $key, $before[ $key ]['quantity'] );
		} else {
			$cart->remove_cart_item( $key );
		}
	}
}

/**
 * Rebuilds a pool's lines in this shop's cart.
 *
 * All-or-nothing, in one request. WooCommerce's own `?wc-ajax=add_to_cart`
 * endpoint takes one product per call, so the alternative is N round trips
 * racing the same session — and a line failing halfway would leave the shopper
 * with some of a pool in their cart and none of the rest. That partial basket
 * is only noticed at checkout, which is why the handoff ladder rates it worse
 * than no basket at all, and why anything that cannot be added sends the buyer
 * to the pool page (where the whole pool can be completed) instead.
 *
 * Adding goes through `WC_Cart::add_to_cart()`, the same call WooCommerce's own
 * AJAX handler makes, so stock, sold-individually limits, add-on data and every
 * plugin hooked into adding to a cart behave exactly as they do normally.
 *
 * No nonce, matching WooCommerce's own `?wc-ajax=add_to_cart`: this is a cart
 * write without a CSRF token, and a nonce printed into a storefront page the
 * shop's page cache then serves to everyone would be stale for all but the
 * first visitor — which would break the handoff outright. The worst a forged
 * request achieves is lines in that shopper's own cart, at prices and stock
 * this shop decides.
 */
function poolbuyr_ajax_handoff() {
	nocache_headers();

	$lines = poolbuyr_request_lines();

	if ( is_wp_error( $lines ) ) {
		wp_send_json_error( array( 'message' => $lines->get_error_message() ) );
	}

	$cart = poolbuyr_cart();

	if ( ! $cart ) {
		wp_send_json_error( array( 'message' => __( 'The cart is unavailable.', 'poolbuyr' ) ) );
	}

	$before = $cart->get_cart();
	$added  = array();

	foreach ( $lines as $line ) {
		try {
			$key = $cart->add_to_cart( $line['product_id'], $line['quantity'], $line['variation_id'] );
		} catch ( Exception $e ) {
			// A product can refuse by throwing rather than by returning false
			// (sold individually, or a plugin's own rule).
			poolbuyr_undo_lines( $cart, $before, $added );

			wp_send_json_error( array( 'message' => $e->getMessage() ) );
		}

		if ( ! $key ) {
			poolbuyr_undo_lines( $cart, $before, $added );

			wp_send_json_error( array( 'message' => __( 'A pooled line could not be added.', 'poolbuyr' ) ) );
		}

		$added[] = $key;
	}

	wp_send_json_success( array( 'added' => count( $added ) ) );
}
add_action( 'wp_ajax_poolbuyr_handoff', 'poolbuyr_ajax_handoff' );
add_action( 'wp_ajax_nopriv_poolbuyr_handoff', 'poolbuyr_ajax_handoff' );
