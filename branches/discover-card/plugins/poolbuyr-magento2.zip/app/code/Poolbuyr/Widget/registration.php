<?php
/**
 * Magento discovers the module through this file: it is the only entry point
 * `app/code` scanning looks for, and it names the module exactly as
 * `etc/module.xml` and every layout/template reference spell it.
 */
declare(strict_types=1);

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Poolbuyr_Widget', __DIR__);
