/**
 * Poolbuyr widget — Magento storefront glue.
 *
 * Two jobs:
 *  1. hand the shop's cart to the embed (window.PoolbuyrWidget.setCart) so a
 *     finished pool can name real products rather than just titles;
 *  2. hold the Tier-2 hook (window.PoolbuyrWidget.buildCart), which turns a pool
 *     the shopper has just joined into this shop's own quote and sends them to
 *     checkout. On Magento that hook is the only way to get a partial cart: the
 *     Magento cart permalink builds one item, so without the hook a multi-item
 *     pool degrades to Poolbuyr's plain buyer checklist.
 *
 * Both are driven from Magento_Customer/js/customer-data, which is where Magento
 * already keeps the cart in page scope. That means no custom controller, no REST
 * token, and it works for guests — which is what a pooled buyer usually is.
 */
define([
    'jquery',
    'Magento_Customer/js/customer-data'
], function ($, customerData) {
    'use strict';

    /** The embed accepts 1–50 lines; anything past that is dropped, not merged. */
    var MAX_LINES = 50;

    /** 100 polls of 300ms. The loader is one CDN script: it lands, or it does not. */
    var LOADER_ATTEMPTS = 100;

    /**
     * The loader carries `async`, so it can execute before or after this module,
     * and when it does execute it *replaces* window.PoolbuyrWidget wholesale —
     * anything attached to the old object goes with it. Hence waiting for the
     * loader's own object (the one carrying __v1) instead of checking once.
     */
    function whenLoaderReady(callback) {
        var attempts = 0;

        (function poll() {
            var api = window.PoolbuyrWidget;

            if (api && api.__v1) {
                callback(api);

                return;
            }

            if (++attempts > LOADER_ATTEMPTS) {
                return;
            }

            window.setTimeout(poll, 300);
        })();
    }

    /**
     * Magento's own product ids, never SKUs — they are what lets a finished pool
     * be rebuilt as a real cart line here later.
     *
     * No unitPrice: the customer-data cart carries a pre-formatted price string
     * ("€12,00"), which cannot be parsed back into a number across currencies and
     * locales. The field is optional in the widget contract, so it is left out
     * rather than guessed at.
     */
    function currentItems() {
        var cart = customerData.get('cart')() || {};

        return $.map(cart.items || [], function (item) {
            // Number() before the check, not after: customer-data hands these over
            // as strings, and '0' is a truthy string.
            var productId = Number(item.product_id),
                quantity = Number(item.qty);

            if (!(productId > 0) || !(quantity > 0)) {
                return null;
            }

            return {
                productId: productId,
                title: item.product_name,
                quantity: quantity
            };
        }).slice(0, MAX_LINES);
    }

    /** Magento renders this hidden input in the content container of every page. */
    function formKey() {
        var input = document.querySelector('input[name="form_key"]');

        if (input && input.value) {
            return input.value;
        }

        // Cached pages are what the cookie exists for; the input is written once
        // per rendered page, the cookie survives a page served from the cache.
        var match = document.cookie.match(/(?:^|;\s*)form_key=([^;]+)/);

        return match ? decodeURIComponent(match[1]) : '';
    }

    /**
     * One request per line, on the storefront route rather than
     * /rest/V1/carts/mine/items: a guest has neither a customer token nor a guest
     * cart id in page scope, and a pooled buyer is usually a guest.
     *
     * jQuery sends X-Requested-With on its own, and that header is what makes
     * Magento\Checkout\Controller\Cart\Add answer with JSON ({backUrl}, or
     * {displayMessages}) instead of a redirect to the cart page.
     */
    function addOne(line, config) {
        return $.ajax({
            url: config.addUrl,
            type: 'POST',
            dataType: 'json',
            data: {
                product: line.id,
                qty: line.quantity,
                form_key: formKey()
            }
        }).then(function (response) {
            if (response && response.displayMessages) {
                // Out of stock, missing option, quantity below the minimum…
                throw new Error('poolbuyr: ' + (response.messages || 'item rejected'));
            }
        });
    }

    /** Sequential: the first refused line stops the rest instead of half-building a cart. */
    function addAll(lines, config) {
        return lines.reduce(function (chain, line) {
            return chain.then(function () {
                return addOne(line, config);
            });
        }, $.when());
    }

    /**
     * A line Magento took but then dropped (a product disabled between the pool
     * and the click, a sold-out variant) would leave the buyer at checkout with a
     * cart that is missing part of the pool — worse than the checklist, because
     * they only find out at payment. So count the cart back before checkout.
     */
    function verifyCart(expected) {
        return customerData.reload(['cart'], true).then(function () {
            var cart = customerData.get('cart')() || {};

            if ((Number(cart.summary_count) || 0) < expected) {
                throw new Error('poolbuyr: cart is missing pooled lines');
            }
        });
    }

    /**
     * window.top, the same window the loader would have navigated. A shop that
     * embeds its storefront in a frame makes top cross-origin and the assignment
     * throws, so falling back to our own window keeps the buyer moving.
     */
    function navigate(url) {
        if (!url) {
            return;
        }

        try {
            window.top.location.href = url;
        } catch (e) {
            window.location.href = url;
        }
    }

    /** 1–50 lines with a positive quantity; a line with no usable id cannot be rebuilt. */
    function normalize(items) {
        var lines = [];

        for (var i = 0; i < (items || []).length && lines.length < MAX_LINES; i++) {
            var line = items[i],
                // variantId first: a configurable product is pooled by its simple
                // variant, because the parent id on its own is not addable without
                // the chosen super attributes.
                id = Number(line.variantId || line.productId),
                quantity = Number(line.quantity);

            if (id > 0 && quantity > 0) {
                lines.push({id: id, quantity: quantity});
            }
        }

        return lines;
    }

    return function (config) {
        whenLoaderReady(function (api) {
            /**
             * The loader calls this hook synchronously and never awaits the return
             * value: it marks the handoff as taken the moment the call returns
             * without throwing. A rejection inside an async hook is therefore
             * invisible from up there — the buyer would be left on the shop with an
             * unchanged cart and the loader's own navigation to the pool would
             * never fire. So every path below that is not a success has to send the
             * top window to ctx.url itself; that is what the navigate() calls in
             * the catch (and the empty-lines guard) are for, not the loader.
             */
            api.buildCart = function (items, ctx) {
                var lines = normalize(items);

                if (!lines.length) {
                    navigate(ctx && ctx.url);

                    return;
                }

                var cart = customerData.get('cart')() || {},
                    expected = (Number(cart.summary_count) || 0) +
                        lines.reduce(function (sum, line) {
                            return sum + line.quantity;
                        }, 0);

                addAll(lines, config)
                    .then(function () {
                        return verifyCart(expected);
                    })
                    .then(function () {
                        navigate(config.checkoutUrl);
                    })
                    .catch(function () {
                        navigate(ctx.url);
                    });
            };

            // ko's subscribe fires once with the current value and again on every
            // cart change, so this keeps the embed in step without a separate
            // initial push. An emptied cart is not pushed: the embed takes 1–50
            // lines and an empty set is outside that contract.
            customerData.get('cart').subscribe(function () {
                var items = currentItems();

                if (items.length) {
                    api.setCart(items);
                }
            });
        });
    };
});
