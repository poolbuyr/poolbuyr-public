<?php
/**
 * Configuration access for the storefront template.
 */
declare(strict_types=1);

namespace Poolbuyr\Widget\Block;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Magento\Store\Model\ScopeInterface;

class Widget extends Template
{
    private const XML_PATH_PUBLISHABLE_KEY = 'poolbuyr_widget/general/publishable_key';
    private const XML_PATH_APP_ORIGIN = 'poolbuyr_widget/general/app_origin';

    /**
     * @var ScopeConfigInterface
     */
    private $scopeConfig;

    /**
     * @param Context $context
     * @param ScopeConfigInterface $scopeConfig
     * @param array $data
     */
    public function __construct(Context $context, ScopeConfigInterface $scopeConfig, array $data = [])
    {
        $this->scopeConfig = $scopeConfig;
        parent::__construct($context, $data);
    }

    /**
     * Store scope, not global: one Magento install can run several storefronts and
     * each of them is a separate vendor account at Poolbuyr.
     *
     * @return string
     */
    public function getPublishableKey(): string
    {
        return trim((string) $this->scopeConfig->getValue(
            self::XML_PATH_PUBLISHABLE_KEY,
            ScopeInterface::SCOPE_STORE
        ));
    }

    /**
     * Trailing slash stripped to match how the loader concatenates this with
     * `/vendor/embed`; empty falls through to the loader's own default.
     *
     * @return string
     */
    public function getAppOrigin(): string
    {
        return rtrim(trim((string) $this->scopeConfig->getValue(
            self::XML_PATH_APP_ORIGIN,
            ScopeInterface::SCOPE_STORE
        )), '/');
    }
}
